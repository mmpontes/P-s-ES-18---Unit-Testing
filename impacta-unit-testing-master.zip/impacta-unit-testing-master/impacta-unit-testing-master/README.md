# Faculdade Impacta - Pós-ES-18: Automação de Testes de Software

 Projeto de testes de unidade - Classe NotaFinal

Participantes;
* Mario Pontes - 1901351
* Rodrigo Santos - 1901853